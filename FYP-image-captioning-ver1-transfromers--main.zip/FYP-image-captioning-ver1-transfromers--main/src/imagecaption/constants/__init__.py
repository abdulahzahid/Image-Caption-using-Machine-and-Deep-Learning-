from pathlib import Path
config_file_path=Path('config\config.yaml')
params_file_path=Path('params.yaml')

