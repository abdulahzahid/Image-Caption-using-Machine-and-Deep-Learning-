# FYP-image-captioning-ver1-transfromers-


## workflows:
1. update config yaml 
2. update params.yaml 
3. update entitiy
4. update teh config manager in src config 
5. update components 
6. update pipeline
7. update main.py
8. update app.py 


